package ch.jugl.testfonct;

public class AdditionFixture {

    public int deuxiemeMontant;
    public int premierMontant;

    public AdditionFixture() {
        // TODO Auto-generated Constructor stub
    }

    public int somme() {
        return premierMontant+deuxiemeMontant;
    }

}
