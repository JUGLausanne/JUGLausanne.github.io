package ch.jugl.testfonct;

public class Core {
    public static String getHello() {
        return "Hello";
    }
}