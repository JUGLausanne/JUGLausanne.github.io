package ch.jugl.testfonct;

public class MathematiqueFixture {

    public String premierArgument;
    public int deuxiemeArgument;

    public MathematiqueFixture() {
    }

    public long quelEstLeResultat() {
        return Integer.parseInt(premierArgument)+deuxiemeArgument;
    }

}
