package ch.jugl.testfonct;

public class AutreFixture {

    public AutreFixture() {
        // TODO Auto-generated Constructor stub
    }

    public String laCouleur(String param1) {
        // TODO Auto-generated Method stub
        return null;
    }

    public String positionnneEnTantQueCouleur(String param1) {
        // TODO Auto-generated Method stub
        return null;
    }

}
