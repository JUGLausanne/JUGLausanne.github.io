package ch.jugl.testfonct;

import java.util.ArrayList;
import java.util.List;

public class Mathematique2Fixture {

    public Mathematique2Fixture() {
    }

    public List<Couleur> query() {
        // TODO Auto-generated Method stub
        List<Couleur> tResult = new ArrayList<Couleur>();
        tResult.add(new Couleur("beu"));
        return tResult;
    }

    public static class Couleur{
        public String couleur;

        public Couleur(String couleur) {
            super();
            this.couleur = couleur;
        }
       
    }
    
}
