package ch.jugl.testfonct;

public class Mathematique3Fixture {

    public Mathematique3Fixture() {
        // TODO Auto-generated Constructor stub
    }

    public String onVeutConvertitUneMonnaieEnEnDontLeMontantEstEst(String param1, String param2, String param3) {
        // TODO Auto-generated Method stub
        return null;
    }

}
