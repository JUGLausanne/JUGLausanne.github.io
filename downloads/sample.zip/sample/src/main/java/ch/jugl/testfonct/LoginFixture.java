package ch.jugl.testfonct;

public class LoginFixture {

    public LoginFixture() {
        // TODO Auto-generated Constructor stub
    }

    public String utiliseLeCompteAvecLeRole(String param1, String param2) {
        // TODO Auto-generated Method stub
        return null;
    }

}
